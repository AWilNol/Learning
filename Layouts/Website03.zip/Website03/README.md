This website is the mockup of the sketch in Warmup 8. 
